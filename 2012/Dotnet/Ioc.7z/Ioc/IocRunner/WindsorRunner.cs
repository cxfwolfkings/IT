﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;

namespace IocRunner
{
    /// <summary>
    /// Castle Windsor性能测试类
    /// </summary>
    public class WindsorRunner : RunnerBase, IRunner
    {
        protected override string Name
        {
            get { return "Castle Windsor"; }
        }

        public void Start(RunType runType)
        {
            var container = new WindsorContainer();
            if (runType == RunType.Singleton)
                container.Register(Component.For(typeof(DatabaseManager)).LifeStyle.Singleton);
            else
                container.Register(Component.For(typeof(DatabaseManager)).LifeStyle.Transient);

            container.Register(Component.For(typeof(IDatabase)).ImplementedBy(typeof(SqlDatabase)));

            Time(() =>
            {
                var manager = container.Resolve<DatabaseManager>();
                manager.Search("SELECT * FROM USER");
            });
        }
    }
}
