﻿using System;
using System.Configuration;

namespace IocRunner
{
    public abstract class RunnerBase
    {
        internal int Iteration { get; } = Convert.ToInt32(ConfigurationManager.AppSettings["Iteration"] ?? "10000");

        internal void Time(Action action)
        {
            CodeTimer.Time(Name, Iteration, action);
        }

        protected abstract string Name { get; }
    }
}
