﻿namespace IocRunner
{
    public class RunManager
    {
        public static void Start(IRunner runner)
        {
            Start(runner, RunType.Transient);
        }

        public static void Start(IRunner runner, RunType runType)
        {
            runner.Start(runType);
        }
    }
}
