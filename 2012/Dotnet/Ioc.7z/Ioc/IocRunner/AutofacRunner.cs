﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Text;

namespace IocRunner
{
    /// <summary>
    /// Autofac性能测试类
    /// </summary>
    public class AutofacRunner : RunnerBase, IRunner
    {
        protected override string Name
        {
            get { return "Autofac"; }
        }

        public void Start(RunType runType)
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<SqlDatabase>().As<IDatabase>();
            if (runType == RunType.Singleton)
                builder.Register(c => new DatabaseManager(c.Resolve<IDatabase>())).SingleInstance();
            else
                builder.Register(c => new DatabaseManager(c.Resolve<IDatabase>()));

            var container = builder.Build();

            Time(() =>
            {
                var manager = container.Resolve<DatabaseManager>();
                manager.Search("SELECT * FROM USER");
            });

            container.Dispose();
        }
    }
}
