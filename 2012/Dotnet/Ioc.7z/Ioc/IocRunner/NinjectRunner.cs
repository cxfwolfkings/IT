﻿using Ninject;
using Ninject.Modules;

namespace IocRunner
{
    /// <summary>
    /// Ninject性能测试类
    /// </summary>
    public class NinjectRunner : RunnerBase, IRunner
    {
        protected override string Name
        {
            get { return "Ninject"; }
        }

        public void Start(RunType runType)
        {
            IKernel kernel = new StandardKernel(new MyNinjectModule(runType));

            Time(() =>
            {
                var manager = kernel.Get<DatabaseManager>();
                manager.Search("SELECT * FROM USER");
            });
        }
    }

    public class MyNinjectModule : NinjectModule
    {
        private RunType _runType = RunType.Transient;

        public MyNinjectModule(RunType runType)
        {
            _runType = runType;
        }

        #region NinjectModule Member

        public override void Load()
        {
            if (_runType == RunType.Singleton)
            {
                Bind<DatabaseManager>().ToSelf().InSingletonScope();
            }
            else
            {
                Bind<DatabaseManager>().ToSelf();
            }
            Bind<IDatabase>().To<SqlDatabase>();
        }

        #endregion
    }
}
