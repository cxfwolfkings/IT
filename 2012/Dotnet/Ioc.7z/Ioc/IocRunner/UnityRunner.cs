﻿using Unity;
using Unity.Lifetime;

namespace IocRunner
{
    /// <summary>
    /// Unity性能测试类
    /// </summary>
    public class UnityRunner : RunnerBase, IRunner
    {
        protected override string Name
        {
            get { return "Unity"; }
        }

        public void Start(RunType runType)
        {
            var container = new UnityContainer();
            if (runType == RunType.Singleton)
                container.RegisterType<DatabaseManager>(new ContainerControlledLifetimeManager());
            else
                container.RegisterType<DatabaseManager>(new TransientLifetimeManager());
            container.RegisterType<IDatabase, SqlDatabase>();

            Time(() =>
            {
                var manager = container.Resolve<DatabaseManager>();
                manager.Search("SELECT * FROM USER");
            });
        }
    }
}
