﻿using Spring.Context;
using Spring.Context.Support;

namespace IocRunner
{
    /// <summary>
    /// Spring.NET性能测试类
    /// </summary>
    public class SpringRunner : RunnerBase, IRunner
    {
        protected override string Name
        {
            get { return "Spring.NET"; }
        }

        public void Start(RunType runType)
        {
            string databaseManagerName;
            if (runType == RunType.Singleton)
                databaseManagerName = "DatabaseManager_Singleton";
            else
                databaseManagerName = "DatabaseManager_Transient";

            Time(() =>
            {
                IApplicationContext context = ContextRegistry.GetContext();
                var manager = (DatabaseManager)context.GetObject(databaseManagerName);
                manager.Search("SELECT * FROM USER");
            });
        }
    }
}
