﻿using StructureMap;

namespace IocRunner
{
    /// <summary>
    /// StructureMap性能测试类
    /// </summary>
    public class StructureMapRunner : RunnerBase, IRunner
    {
        protected override string Name
        {
            get { return "StructureMap"; }
        }

        public void Start(RunType runType)
        {
            var container = new Container(_ =>
            {
                if (runType == RunType.Singleton)
                    _.For<DatabaseManager>().Singleton();
                else
                    _.For<DatabaseManager>();
                _.For<IDatabase>().Use<SqlDatabase>();
            });

            Time(() =>
            {
                var manager = container.GetInstance<DatabaseManager>();
                manager.Search("SELECT * FROM USER");
            });
        }
    }
}
