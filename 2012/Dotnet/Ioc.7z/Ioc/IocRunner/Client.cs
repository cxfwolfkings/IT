﻿using Autofac;
using Autofac.Configuration;
using Microsoft.Extensions.Configuration;
using SC.Common.Utils;
using System;

namespace IocRunner
{
    /// <summary>
    /// 场景类
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Autofac示例
        /// </summary>
        public static void AutofacDemo()
        {
            var builder = new ContainerBuilder();
            // 通过AS可以让DatabaseManager类中通过构造函数依赖注入类型相应的接口。
            //builder.RegisterType<SqlDatabase>().As<IDatabase>();
            /**
             * 显然以上的程序中，SqlDatabase或者OracleDatabase已经暴露于客户程序中了，现在我想将该类型选择通过文件配置进行读取。
             * Autofac自带了一个Autofac.Configuration.dll 非常方便地对类型进行配置，避免了程序的重新编译。
             * 
             * 注册配置文件中的模块
             * Nuget中添加引用Microsoft.Extensions.Configuration
             * Nuget中添加引用Microsoft.Extensions.Configuration.Xml
             * 示例：var appConfig = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddXmlFile("config.xml");
             */
            var appConfig = new ConfigurationBuilder();
            IConfiguration _configuration = appConfig.Build().GetSection("autofac");
            builder.RegisterModule(new ConfigurationModule(_configuration));
            // 这里通过ContainerBuilder方法RegisterType对DatabaseManager进行注册，注册的类型在相应得到的容器中可以Resolve你的DatabaseManager实例。
            //builder.RegisterType<DatabaseManager>();
            // 另外还有一种方式，通过Register方法进行注册
            builder.Register(c => new DatabaseManager(c.Resolve<IDatabase>()));
            // Build()方法生成一个对应的Container实例，这样，就可以通过Resolve解析到注册的类型实例。
            using (var container = builder.Build())
            {
                var manager = container.Resolve<DatabaseManager>();
                manager.Search("SELECT * FORM USER");
            }
        }

        /// <summary>
        /// IOC框架性能比拼
        /// </summary>
        public static void PerformanceDemo()
        {
            CodeTimer.Initialize();

            Console.WriteLine("IOC - Singleton");
            // Autofac Singleton 
            RunManager.Start(new AutofacRunner(), RunType.Singleton);
            // Castle Windsor 
            RunManager.Start(new WindsorRunner(), RunType.Singleton);
            // Unity 
            RunManager.Start(new UnityRunner(), RunType.Singleton);
            // Spring.NET 
            RunManager.Start(new SpringRunner(), RunType.Singleton);
            // StructureMap 
            RunManager.Start(new StructureMapRunner(), RunType.Singleton);
            // Ninject 
            RunManager.Start(new NinjectRunner(), RunType.Singleton);

            Console.WriteLine("===================================");

            Console.WriteLine("IOC - Transient");
            // Autofac Singleton 
            RunManager.Start(new AutofacRunner(), RunType.Transient);
            // Castle Windsor 
            RunManager.Start(new WindsorRunner(), RunType.Transient);
            // Unity 
            RunManager.Start(new UnityRunner(), RunType.Transient);
            // Spring.NET 
            RunManager.Start(new SpringRunner(), RunType.Transient);
            // StructureMap 
            RunManager.Start(new StructureMapRunner(), RunType.Transient);
            // Ninject 
            RunManager.Start(new NinjectRunner(), RunType.Transient);
        }
    }
}
